package com.sof.soofthostal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class soofthostalspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
