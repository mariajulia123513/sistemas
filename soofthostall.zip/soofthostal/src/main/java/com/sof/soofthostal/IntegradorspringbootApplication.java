package com.sof.soofthostal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradorspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradorspringbootApplication.class, args);
	}

}
